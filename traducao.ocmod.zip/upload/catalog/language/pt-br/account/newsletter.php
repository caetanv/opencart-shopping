<?php
// Heading
$_['heading_title']    = 'Novidades, ofertas e promoções por e-mail';

// Text
$_['text_account']     = 'Minha conta';
$_['text_newsletter']  = 'Informativo';
$_['text_success']     = 'A sua assinatura em nosso informativo foi modificada.';

// Entry
$_['entry_newsletter'] = 'Deseja receber?';