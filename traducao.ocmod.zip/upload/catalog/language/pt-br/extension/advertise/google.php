<?php
// Text
$_['text_cron_email_message'] = '<p>Este é um relatório automatizado da última tarefa CRON realizada pela sua extensão do Google Shopping.</p><p>%s</p>';
$_['text_cron_email_subject'] = 'Relatório de tarefa CRON - Google Shopping no OpenCart';
