<?php
// Text
$_['text_title']  = 'Frete por peso';
$_['text_weight'] = 'Peso:';