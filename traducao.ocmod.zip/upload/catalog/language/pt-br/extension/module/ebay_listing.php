<?php
// Heading
$_['heading_title'] = 'Produtos no eBay';