<?php
// Text
$_['text_subject']      = '%s - Atualização do Pedido nº %s';
$_['text_order_id']     = 'Pedido nº:';
$_['text_date_added']   = 'Atualizado em:';
$_['text_order_status'] = 'Seu pedido foi atualizado para a seguinte situação:';
$_['text_comment']      = 'O comentário para o seu pedido é:';
$_['text_link']         = 'Para acompanhar o andamento do seu pedido, clique no link abaixo:';
$_['text_footer']       = 'Caso tenha alguma dúvida, responda este e-mail.';