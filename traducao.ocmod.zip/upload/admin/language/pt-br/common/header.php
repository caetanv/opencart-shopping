<?php
// Heading
$_['heading_title']      = 'OpenCart';

// Text
$_['text_profile']       = 'Meu perfil';
$_['text_store']         = 'Lojas';
$_['text_help']          = 'Ajuda';
$_['text_homepage']      = 'Site oficial';
$_['text_support']       = 'Fórum de suporte';
$_['text_documentation'] = 'Documentação';
$_['text_logout']        = 'Sair';