<?php
// Heading
$_['heading_title']    = 'Outros';

// Text
$_['text_success']     = 'Outros modificado com sucesso!';
$_['text_list']        = 'Listando outros';

// Column
$_['column_name']      = 'Outros';
$_['column_status']    = 'Situação';
$_['column_action']    = 'Ação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar as extensões do tipo outros!';