<?php
// Heading
$_['heading_title']     = 'Conteúdo HTML';

// Text
$_['text_extension']    = 'Extensões';
$_['text_success']      = 'Conteúdo HTML modificado com sucesso!';
$_['text_edit']         = 'Editando Conteúdo HTML';

// Entry
$_['entry_name']        = 'Título do módulo';
$_['entry_title']       = 'Título';
$_['entry_description'] = 'Conteúdo';
$_['entry_status']      = 'Situação';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar a extensão Conteúdo HTML!';
$_['error_name']        = 'Título do módulo deve ter entre 3 e 64 caracteres!';