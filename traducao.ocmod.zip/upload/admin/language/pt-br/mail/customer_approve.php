<?php
// Text
$_['text_subject'] = '%s - Sua conta foi aprovada!';
$_['text_welcome'] = 'Obrigado por se cadastrar na loja %s!';
$_['text_login']   = 'Sua conta foi aprovada, agora você pode acessar sua conta utilizando seu e-mail e sua senha através de nossa loja:';
$_['text_service'] = 'Ao acessar sua conta, você poderá visualizar o histórico de seus pedidos, imprimir faturas, fazer downloads que tenha comprado, modificar as informações de sua conta e muito mais.';
$_['text_thanks']  = 'Atenciosamente,';