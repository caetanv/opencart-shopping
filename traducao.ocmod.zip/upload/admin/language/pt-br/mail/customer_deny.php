<?php
// Text
$_['text_subject'] = '%s - Sua conta não foi aprovada!';
$_['text_welcome'] = 'Obrigado por se cadastrar na loja %s!';
$_['text_denied']  = 'Sua conta infelizmente não foi aprovada. Para mais informações, entre em contato conosco:';
$_['text_thanks']  = 'Atenciosamente,';
